import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth-middleware'
import fs from 'fs/promises'
import path from 'path'
import { v4 as uuidv4 } from 'uuid'
import sharp from 'sharp'

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'rooms')

async function ensureDir() {
  try {
    await fs.access(UPLOAD_DIR)
  } catch {
    await fs.mkdir(UPLOAD_DIR, { recursive: true })
  }
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = await requireAuth(req, ['HOTEL_ADMIN', 'HOTEL_SUB_ADMIN'])
    if (auth.error) return auth.error

    const hotelId = auth.payload.hotel_id
    const resolvedParams = await params
    const roomId = parseInt(resolvedParams.id)

    if (isNaN(roomId)) return NextResponse.json({ success: false, message: 'Invalid ID' }, { status: 400 })

    const room = await prisma.room_details.findUnique({
      where: { id: roomId },
      include: { room_type: true }
    })

    if (!room || room.room_type.hotel_id !== hotelId) {
      return NextResponse.json({ success: false, message: 'Room not found' }, { status: 404 })
    }

    const images = await prisma.room_images.findMany({
      where: { room_detail_id: roomId },
      orderBy: { sort_order: 'asc' }
    })

    return NextResponse.json({ success: true, data: images })
  } catch (error) {
    console.error('Fetch room images error:', error)
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = await requireAuth(req, ['HOTEL_ADMIN', 'HOTEL_SUB_ADMIN'])
    if (auth.error) return auth.error

    const hotelId = auth.payload.hotel_id
    const resolvedParams = await params
    const roomId = parseInt(resolvedParams.id)

    if (isNaN(roomId)) return NextResponse.json({ success: false, message: 'Invalid ID' }, { status: 400 })

    const room = await prisma.room_details.findUnique({
      where: { id: roomId },
      include: { room_type: true }
    })

    if (!room || room.room_type.hotel_id !== hotelId) {
      return NextResponse.json({ success: false, message: 'Room not found' }, { status: 404 })
    }

    const formData = await req.formData()
    const files = formData.getAll('files') as File[]

    if (!files || files.length === 0) {
      return NextResponse.json({ success: false, message: 'No files provided' }, { status: 400 })
    }
    const MAX_FILE_SIZE = 1 * 1024 * 1024 // 1 MB

for (const file of files) {
  if (file.size > MAX_FILE_SIZE) {
    return NextResponse.json(
      {
        success: false,
        message: `${file.name} exceeds the 1 MB limit.`,
      },
      { status: 400 }
    )
  }
}
    await ensureDir()
    const uploadedImages = []

    const maxSort = await prisma.room_images.aggregate({
      where: { room_detail_id: roomId },
      _max: { sort_order: true }
    })
    let currentSortOrder = (maxSort._max.sort_order || 0) + 1

    for (const file of files) {
      if (!(file instanceof Blob)) continue

      const buffer = Buffer.from(await file.arrayBuffer())
      const filename = `${uuidv4()}.webp`
      const filepath = path.join(UPLOAD_DIR, filename)

      await sharp(buffer)
        .resize(1920, 1080, { fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 80 })
        .toFile(filepath)

      const imageUrl = `/uploads/rooms/${filename}`
      
      const imgRecord = await prisma.room_images.create({
        data: {
          room_detail_id: roomId,
          image_url: imageUrl,
          is_cover: false,
          sort_order: currentSortOrder++
        }
      })

      uploadedImages.push(imgRecord)
    }

    // Check if there's any cover, if not make the first one cover
    const coverExists = await prisma.room_images.findFirst({
      where: { room_detail_id: roomId, is_cover: true }
    })
    
    if (!coverExists && uploadedImages.length > 0) {
      await prisma.room_images.update({
        where: { id: uploadedImages[0].id },
        data: { is_cover: true }
      })
      uploadedImages[0].is_cover = true
    }

    return NextResponse.json({ success: true, data: uploadedImages, message: 'Uploaded successfully' })
  } catch (error) {
    console.error('Upload room image error:', error)
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 })
  }
}
