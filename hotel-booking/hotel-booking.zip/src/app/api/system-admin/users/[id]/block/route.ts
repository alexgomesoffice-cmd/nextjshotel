import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth-middleware'
import { blockUserSchema } from '@/lib/validations/auth'

type Params = {
  params: Promise<{ id: string }>
}

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const auth = await requireAuth(req, ['SYSTEM_ADMIN'])
    if (auth.error) return auth.error

    const { id } = await params
    const userId = parseInt(id)

    const body = await req.json()
    const result = blockUserSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, message: 'Validation error', errors: result.error.issues },
        { status: 400 }
      )
    }

    const userExists = await prisma.end_users.findUnique({ where: { id: userId, deleted_at: null } })
    if (!userExists) {
      return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 })
    }

    const updatedUser = await prisma.end_users.update({
      where: { id: userId },
      data: { is_blocked: result.data.is_blocked },
      select: { id: true, name: true, email: true, is_blocked: true },
    })

    return NextResponse.json({ success: true, message: `User ${result.data.is_blocked ? 'blocked' : 'unblocked'}`, data: updatedUser })
  } catch (error) {
    console.error('Failed to block/unblock user:', error)
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 })
  }
}
